<!DOCTYPE html>
<head>
<title>Result</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
</head>
<body>
<div class="alert alert-success">
  <strong>
			<?php

			require_once 'token.php';
			$val = $_POST["token"];


			if(isset($_POST['input'])){
				if(token::checkToken($val,$_COOKIE['SesT'])){
					echo "Valid request: ".$_POST['input']. "<br>";
					echo "Session ID:  ".$_COOKIE['SesT']."<br>";
					echo "Token:  ".$val;	
						
				}
				else{
				   echo "<b>Invalid CSRF token:"." ".$_POST['input']."</b>";
				}
			}
			?>

   </strong>
</div>
</body>

</html>
