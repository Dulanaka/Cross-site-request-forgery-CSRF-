<!DOCTYPE html>
<head>
<title>Home</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<script>
	
	$(document).ready(function(){

	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			document.getElementById("token_value").setAttribute('value', this.responseText) ;
		}
	};
	
	xhttp.open("GET", "tokenGenerate.php", true);
	xhttp.send();
	
	});
</script>
</head>

<div class="alert alert-success">
  <strong>
 
			<?php
			if(isset($_POST['username'],$_POST['password'])){
				$user_name = $_POST['username'];
				$password = $_POST['password'];
				if($user_name == 'admin' && $password == 'admin'){
					echo 'Successfully logged in';
				
				}
				else{
					echo 'Invalid Credentials';
					exit();
				}
			}
			?>
</strong>
</div>

<style type="text/css">
	div .input{
		width: 40%;
		border-width: 0.5em;
	}
</style>

<body><br><br>

    <div  align="center" >
    		<h2>Write Something</h2>
            <form action="result.php" method="post">
          
             <input id="input"  name="input" placeholder="" class="input"><br><br>
		     <input type="hidden" name="token" value="" id="token_value"/>
             <input type="submit" name="Submit" value="Update" class="btn btn-default">    
                    
            </form>
    </div>
</body>

</html>