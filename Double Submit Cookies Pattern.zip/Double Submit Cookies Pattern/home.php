
<!DOCTYPE html>
<html>
	<head>
		<title>Cross Site Request Forgery Protection</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <link href="style.css" rel="stylesheet" id="bootstrap-css">
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

	<script>
	
	$(document).ready(function(){
	
	var cookie_value = "";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
	var csrf = decodedCookie.split(';')[2]
	// alert(decodedCookie)
	if(csrf.split('=')[0] = "csrfTokenCookie" ){
		// alert(csrf.split('csrfTokenCookie=')[1])
		cookie_value = csrf.split('csrfTokenCookie=')[1];
		document.getElementById("tokenIn_hidden_field").setAttribute('value', cookie_value) ;
	}
	});

</script>
<style type="text/css">
	div .input{
		width: 40%;
		border-width: 0.5em;
	}
</style>

  <head>
	<body>
		<div class="alert alert-success">
  <strong>
<?php
if(isset($_POST['username'],$_POST['password'])){
	$uname = $_POST['username'];
	$pwd = $_POST['password'];
	if($uname == 'admin' && $pwd == 'admin'){
		echo 'Successfully logged in';
		session_start();
		$_SESSION['token'] = base64_encode(openssl_random_pseudo_bytes(32));
		$session_id = session_id();
		setcookie('sessionCookie',$session_id,time()+ 60*60*24*365 ,'/',"",false,false);
		setcookie('csrfTokenCookie',$_SESSION['token'],time()+ 60*60*24*365 ,'/',false,false);
		
	}else{
		echo 'Invalid Credentials';
		exit();
	}
}
?>
</strong>
</div> 
<br><br>

 <div  align="center" >
    		<h2>Write Something</h2>
            <form action="result.php" method="post">
          
             <input type="text" name="updatepost" placeholder="" class="input"><br><br>
		     <input type="hidden" name="token" value="" id="tokenIn_hidden_field"/>
             <input type="submit"  value="Update" class="btn btn-info btn-md">    
                    
            </form>
    </div>

                

	</body> 
</html>
